package com.example.justalk_main;

import junit.framework.TestCase;

public class CustomViewHolderImplTest extends TestCase {

}