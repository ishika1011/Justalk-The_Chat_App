package com.example.justalk_main;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.justalk_main.adapters.Adapterusers;
import com.example.justalk_main.models.ModelUser;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class usersFragment extends Fragment {

    RecyclerView recyclerView;
    Adapterusers adapterUsers;
    List<ModelUser> userList;

    //firebaseauth
    FirebaseAuth firebaseAuth;


    private String mParam1;
    private String mParam2;


    public usersFragment() {
        // Required empty public constructor
    }


    //public static usersFragment newInstance(String param1, String param2) {
    //  usersFragment fragment = new usersFragment();
    //Bundle args = new Bundle();
    //args.putString(ARG_PARAM1, param1);
    //args.putString(ARG_PARAM2, param2);
    //fragment.setArguments(args);
    //return fragment;
    //}

    // @Override
    //public void onCreate(Bundle savedInstanceState) {
    //  super.onCreate(savedInstanceState);
    //if (getArguments() != null) {
    //  mParam1 = getArguments().getString(ARG_PARAM1);
    //mParam2 = getArguments().getString(ARG_PARAM2);
    //}
    //}

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_users, container, false);

        //firebase auth
        FirebaseAuth firebaseAuth;

        //init recyclerview
        recyclerView = view.findViewById(R.id.users_recyclerview);

        //
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        //init user list
        userList = new ArrayList<>();

        //get all users
        getAllUsers();

        return view;
    }

    private void getAllUsers() {

        //get current user
        FirebaseUser fUser = FirebaseAuth.getInstance().getCurrentUser();

        //get path of database named
        String path = null;
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference();

        //get
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                userList.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    ModelUser modelUser = ds.getValue(ModelUser.class);

                    Toast.makeText(getActivity(), modelUser.getName(), Toast.LENGTH_SHORT).show();
                    //get all users....
                    if (!modelUser.getUid().equals(fUser.getUid())) {
                        userList.add(modelUser);
                    }
                    //adapter
                    adapterUsers = new Adapterusers(getActivity(), userList);
                    //set adapter.....
                    recyclerView.setAdapter(adapterUsers);


                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void searchUsers(String s) {
        //get current user
        FirebaseUser fUser = FirebaseAuth.getInstance().getCurrentUser();
        //get path of database named
        String path = null;
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
        //get
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                userList.clear();
                for (DataSnapshot ds : dataSnapshot.getChildren()) {
                    ModelUser modelUser = ds.getValue(ModelUser.class);

                    //get all users....
                    if (!modelUser.getUid().equals(fUser.getUid())) {

                        if (modelUser.getName().toLowerCase().contains(s.toLowerCase()) ||
                                modelUser.getEmail().toLowerCase().contains(s.toLowerCase())) {
                            userList.add(modelUser);
                        }
                    }
                    //adapter
                    adapterUsers = new Adapterusers(getActivity(), userList);
                    //refresh adapter
                    adapterUsers.notifyDataSetChanged();
                    //set adapter.....
                    recyclerView.setAdapter(adapterUsers);


                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    private void checkUserstatus() {
        FirebaseUser user = firebaseAuth.getCurrentUser();
        if ((user != null)) {


        } else {
            startActivity((new Intent(getActivity(), MainActivity.class)));
            getActivity().finish();
        }
    }


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        setHasOptionsMenu(true);//to show menu....
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        inflater.inflate(R.menu.menu_main, menu);

        //searchview
        MenuItem item = menu.findItem((R.id.action_search));
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(item);

        //search listner
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                //called when user....
                if (!TextUtils.isEmpty(s.trim())) {
                    //search text contains...
                    searchUsers(s);
                } else {
                    //search text empty
                    getAllUsers();
                }

                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                //called when user....
                if (!TextUtils.isEmpty(s.trim())) {
                    //search text contains...
                    searchUsers(s);
                } else {
                    //search text empty
                    getAllUsers();
                }

                return false;
            }
        });
        super.onCreateOptionsMenu(menu, inflater);
    }





    //handle menu

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        //get item id
        int id=item.getItemId();
        if(id==R.id.action_logout){
            firebaseAuth.signOut();
            checkUserstatus();
        }
        return super.onOptionsItemSelected(item);
    }
}


