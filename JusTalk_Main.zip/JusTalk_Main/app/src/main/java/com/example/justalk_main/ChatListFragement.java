package com.example.justalk_main;

import android.app.Activity;

public class ChatListFragement extends Activity {
}
