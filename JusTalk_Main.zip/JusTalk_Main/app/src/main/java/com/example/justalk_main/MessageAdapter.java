package com.example.justalk_main;

///public class MessageAdapter  extends RecyclerView.Adapter.CustomViewHolder{
  //  public void notifyDataSetChanged() {
  //  }

   // class CustomViewHolder extends RecyclerView.ViewHolder {
      //  TextView textView;

   //     public CustomViewHolder(View itemView) {
     //       super(itemView);
    //        textView=itemView.findViewById(R.id.textMessage);
   //     }
  //  }

  //  List<com.example.justalk_main.ResponseMessage>responseMessageList;


   // public MessageAdapter(List<com.example.justalk_main.ResponseMessage> responsMessageList) {
  //      this.responseMessageList=responsMessageList;

    //    }

  //      @Override
    //    public int getItemVirwType(int position){
    //    if(responseMessageList.get(position).isMe()){
    //        return R.layout.activity_me_bubble;
    //    }
     //   return R.layout.activity_bot_bubble;
  //  }

     //   @Override
     //   public CustomViewHolder OnCreateViewHolder(@NotNull ViewGroup parent, int ViewType) {
     //       boolean attachToRoot;
     //       return new CustomViewHolder(LayoutInflater.from(parent.getContext()).inflate(ViewType,parent, attachToRoot false);
     //   }

     //   @Override
    //    public void onBindViewHolder(MessageAdapter.CustomViewHolder Holder, int position) {
    //        Holder.textView.setText(responseMessageList.get(position).getTextMessage());
    //    }



    //    @Override
    //    public int getItemCount() {
    //        return responseMessageList.size();
   //     }
// }





