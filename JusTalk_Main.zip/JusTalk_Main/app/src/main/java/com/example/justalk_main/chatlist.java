package com.example.justalk_main;

//public class chatlist  extends RecyclerView.Adapter.MyHolder{
    //context context;


   // List<ModelUser> userList;
  //  private HashMap<String,String> lastmessageMap;
  //  private Object UserName;
  //  private Object LastMessage;

    //constructor
   // public void Adapterchatlist(context context, List<ModelUser> userList, HashMap<String,String>lastmessageMap){
   //     this.context=context;
  //      this.userList=userList;
 //       this.lastmessageMap=lastmessageMap;
 //   }

   // @NonNull
  //  @Override
  //  public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
   //     boolean attachToRoot;
   //     View view= LayoutInflater.from(context).inflate(R.layout.row_chatlist,ViewGroup,attachToRoot:false);
   //     return new MyHolder(View);
   // }



  //  @Override
   // public void onBindViewHolder(@NonNull Adapterchatlist.MyHolder holder, int position) {
    //    String hisUid=userList.get(position).getUid();
     //   String userImage=userList.get(position).getImage();
     //   String userName=userList.get(position).getName();
     //   String lastMessage=lastmessageMap.get(hisUid);

      //  MyHolder.name.setText(UserName);
    //    if (lastMessage!=null || lastMessage.equals("default")){
    //        MyHolder.lastMessageTv.setVisibility(View.GONE);
     //   }
    //    else{
    //        MyHolder.lastMessageTv.setVisibility(View.VISIBLE);
     //       MyHolder.lastMessageTv.setVisibility((Integer) LastMessage);
     //   }
     //   try {
      //      CookieHandler picasso;
     //       picasso.get().load(userImage).placeholder(R.drawable.ic_default_img).into();
      //  }



   // }

  //  @Override
  //  public int getItemCount() {
   //     return userList.size();//size of list
   // }

  //  static class MyHolder extends RecyclerView.ViewHolder{

     //   public static View name;
      //  public static MediaRouteButton lastMessageTv;
     //   ImageView profileIv,onlinestatusIv;
    //    TextView lastmsgTv;

    //    public MyHolder(@NonNull View itemView){
      //      super(itemView);
         //   profileIv=itemView.findViewById(R.id.profileIv);
        //    onlinestatusIv=itemView.findViewById(R.id.onlinestatusIv);
         //   name=itemView.findViewById(R.id.name);
      //      lastmsgTv=itemView.findViewById(R.id.lastmsgTv);
    //    }
 //   }
//}
