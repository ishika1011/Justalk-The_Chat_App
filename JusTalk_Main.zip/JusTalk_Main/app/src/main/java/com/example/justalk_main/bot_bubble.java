package com.example.justalk_main;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class bot_bubble extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bot_bubble);
    }
}