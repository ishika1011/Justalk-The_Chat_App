package com.example.justalk_main;

//public class CustomViewHolderImpl extends CustomViewHolder {
   // public CustomViewHolderImpl(View itemView) {
  //      super(itemView);
 //   }
//}
