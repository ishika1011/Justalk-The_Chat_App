package com.example.justalk_main;

public class MainActivity {
}
